/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concessionaria;

/**
 *
 * @author Aluno
 */
public class Concessionaria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Carro carro = new Carro("fiat", 2000);
        AutoPeca autopeca = new AutoPeca();
        
        carro.AutoPeca();
        carro.getAnofabr();
    }
    
}
