/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concessionaria;

/**
 *
 * @author Aluno
 */
public class Carro implements associacao {
   public int associado = 1;
   private String modelo;
   private int Anofabr;
   
            // GET e SET
    public int getAssociado() {
        return associado;
    }

    public void setAssociado(int asssociado) {
        this.associado = asssociado;
    }

    public String getModelo() {
        return modelo;
    }

   
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnofabr() {
        return Anofabr;
    }

    public void setAnofabr(int Anofabr) {
        this.Anofabr = Anofabr;
    }
    
            //Metodos

    @Override
    public void AutoPeca() {
        System.out.println("Pertenço a uma Autopeça");
    }

    
     public Carro(String modelo, int Anofabr) {
        this.modelo = modelo;
        this.Anofabr = Anofabr;
    }

    
    
}
