/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concessionaria;

/**
 *
 * @author Aluno
 */
public class AutoPeca {
    private String nome;   
    private int numCliente;
    
    public void Concerto(){
        System.out.println("Carro em concerto");
    }
}
